﻿namespace VaporStore.DataProcessor
{
	using System;
	using Data;

	public static class Serializer
	{
		public static string ExportGamesByGenres(VaporStoreDbContext context, string[] genreNames)
		{
			return "ToDo";
		}

		public static string ExportUserPurchasesByType(VaporStoreDbContext context, string storeType)
		{
			return "ToDo";
		}
	}
}