﻿using P01_HospitalDatabase.Data;
using System;

namespace P01_HospitalDatabase
{
    class Program
    {
        static void Main(string[] args)
        {
            HospitalContext context = new HospitalContext();             

        }
    }
}
