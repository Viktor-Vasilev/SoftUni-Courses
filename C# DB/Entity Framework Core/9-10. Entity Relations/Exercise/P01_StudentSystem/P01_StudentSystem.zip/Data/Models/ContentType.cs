﻿namespace P01_StudentSystem.Data.Models
{
    public enum ContentType
    {
        Aplication = 10,
        Pdf = 20,
        Zip = 30
    }
}