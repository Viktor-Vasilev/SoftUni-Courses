﻿using P03_SalesDatabase.Data;
using System;

namespace P03_SalesDatabase
{
    class Program
    {
        static void Main(string[] args)
        {
            SalesContext context = new SalesContext();
        }
    }
}
