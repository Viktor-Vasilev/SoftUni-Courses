﻿using CounterStrike.Models.Guns.Contracts;
using CounterStrike.Models.Players.Contracts;
using CounterStrike.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Text;

namespace CounterStrike.Models.Players
{
    public abstract class Player : IPlayer
    {
        private  int health;
        private string username;
        private int armor;
        private IGun gun;

        public Player(string username, int health, int armor, IGun gun)
        {
            this.Username = username;
            this.Health = health;
            this.Armor = armor;
            this.Gun = gun;
        }

        public int Health 
        {
            get
            {
                return this.health;
            }
            private set
            {
                if (value < 0)
                {
                    //TODO: Player health cannot be below or equal to 0 ???
                    throw new ArgumentException(ExceptionMessages.InvalidPlayerHealth);
                }

                this.health = value;
            }
        }

        public int Armor
        {
            get
            {
                return this.armor;
            }
            private set
            {
                if (value < 0)
                {                  
                    throw new ArgumentException(ExceptionMessages.InvalidPlayerArmor);
                }

                this.armor = value;
            }
        }

        public IGun Gun
        {
            get 
            {
                return this.gun;
            }
            private set
            {
                if (value == null)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidGun);
                }

                this.gun = value;
            }
        
        }    
      
        public string Username
        {
            get
            {
                return this.username;
            }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(ExceptionMessages.InvalidPlayerName);
                }

                this.username = value;
            }
        }

        public bool IsAlive
            => this.Health > 0;

        public void TakeDamage(int points)
        {
            //TODO: Do I need this? ???

            //if (!this.IsAlive)
            //{
            //    return;
            //}

            if (this.Armor > 0)
            {
                this.Armor -= points;

                if (this.Armor < 0)
                {
                    this.Health -= this.Armor * -1;
                    this.Armor = 0;
                }
            }
            else
            {
                this.Health -= points;
            }
        
        
        }
    }
}
