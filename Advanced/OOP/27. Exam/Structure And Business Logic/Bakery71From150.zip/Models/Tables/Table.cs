﻿using Bakery.Models.BakedFoods.Contracts;
using Bakery.Models.Drinks.Contracts;
using Bakery.Models.Tables.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bakery.Models.Tables
{
    public abstract class Table : ITable
    {
        private int capacity;
        private int numberOfPeople;
        private readonly List<IBakedFood> foodOrders;
        private readonly List<IDrink> drinkOrders;

        protected Table(int tableNumber, int capacity, decimal pricePerPerson)
        {
            this.TableNumber = tableNumber;
            this.Capacity = capacity;
            this.PricePerPerson = pricePerPerson;
            this.foodOrders = new List<IBakedFood>();
            this.drinkOrders = new List<IDrink>();
        }

        public IReadOnlyCollection<IBakedFood> FoodOrders => (IReadOnlyCollection<IBakedFood>)this.foodOrders;
        public IReadOnlyCollection<IBakedFood> Drinks => (IReadOnlyCollection<IBakedFood>)this.drinkOrders;

        public int TableNumber { get;}
        public int Capacity
        {
            get
            {
                return this.capacity;
            }
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Capacity has to be greater than 0");
                }
                this.capacity = value;
            }
        }
        public int NumberOfPeople
        {
            get 
            { 
                return this.numberOfPeople;
            }
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Cannot place zero or less people!");
                }
                this.numberOfPeople = value;
            }
        }
        public virtual decimal PricePerPerson { get;}
              
        public decimal Price { get; set; }

        bool ITable.IsReserved => throw new NotImplementedException();

        public abstract void Clear();

        public abstract decimal GetBill();

        public abstract string GetFreeTableInfo();

        public abstract void OrderDrink(IDrink drink);

        public abstract void OrderFood(IBakedFood food);

        public abstract void Reserve(int numberOfPeople);
        
    }
}
