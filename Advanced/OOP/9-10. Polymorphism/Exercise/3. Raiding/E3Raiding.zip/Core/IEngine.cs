﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Raiding.Core
{
   public interface IEngine
    {
        void Run();
    }
}
