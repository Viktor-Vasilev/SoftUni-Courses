﻿

namespace Vehicles.Utilities
{
    public static class ExceptionMessages
    {
        public const string InvalidFuelAmmount = "Cannot fit {0} fuel in the tank";


        public const string NegativeFuelAmmount = "Fuel must be a positive number";
    }
}
