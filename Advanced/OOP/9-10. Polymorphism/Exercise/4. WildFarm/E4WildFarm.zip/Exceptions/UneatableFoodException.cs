﻿

using System;

namespace E4WildFarm.Exceptions
{
    public class UneatableFoodException : Exception
    {      
        public UneatableFoodException(string message) : base(message)
        {

        }
    }
}
