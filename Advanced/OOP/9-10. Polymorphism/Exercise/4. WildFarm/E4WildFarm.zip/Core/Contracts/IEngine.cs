﻿

namespace E4WildFarm.Core.Contracts
{
    public interface IEngine
    {
        void Run();

    }
}
