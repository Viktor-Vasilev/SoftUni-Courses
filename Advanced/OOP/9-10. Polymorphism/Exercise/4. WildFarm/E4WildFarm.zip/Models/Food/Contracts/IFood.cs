﻿

namespace E4WildFarm.Models.Food.Contracts
{
    public interface IFood
    {
        int Quantity { get; }



    }
}
