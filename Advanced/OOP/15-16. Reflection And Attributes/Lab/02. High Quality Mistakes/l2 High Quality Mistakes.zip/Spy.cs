﻿namespace Stealer
{
    using System;
    using System.Linq;
    using System.Reflection;
    using System.Text;

    public class Spy
    {
        public string StealFieldInfo(string investigatedClass, params string[] searchedFields)
        {
            StringBuilder sb = new StringBuilder();

            Type classType = Assembly.GetExecutingAssembly()
                                        .GetTypes()
                                        .FirstOrDefault(x => x.Name == investigatedClass);

            FieldInfo[] fields = classType.GetFields(BindingFlags.Public |
                                                     BindingFlags.Instance |
                                                     BindingFlags.Static |
                                                     BindingFlags.NonPublic);
            Object classInstance = Activator.CreateInstance(classType);


            sb.AppendLine($"Class under investigation: {investigatedClass}");

            foreach (FieldInfo field in fields.Where(x => searchedFields.Contains(x.Name)))
            {
                sb.AppendLine($"{field.Name} = {field.GetValue(classInstance)}");
            }


            return sb.ToString().Trim();
        }

        public string AnalyzeAcessModifiers(string className)
        {
            StringBuilder sb = new StringBuilder();

            Type classType = Assembly.GetExecutingAssembly()
                                    .GetTypes()
                                    .FirstOrDefault(x => x.Name == className);

            FieldInfo[] fields = classType.GetFields(BindingFlags.Public |
                                                              BindingFlags.Instance |
                                                              BindingFlags.Static);

            MethodInfo[] publicMethodModifiers = classType.GetMethods(BindingFlags.Public |
                                                                     BindingFlags.Instance);

            MethodInfo[] privateMethodModifiers = classType.GetMethods(BindingFlags.NonPublic |
                                                                       BindingFlags.Instance);

            foreach (FieldInfo field in fields)
            {
                sb.AppendLine($"{field.Name} must be private!");
            }
            foreach (MethodInfo method in privateMethodModifiers.Where(x => x.Name.StartsWith("get")))
            {
                sb.AppendLine($"{method.Name} have to be public");
            }
            foreach (MethodInfo method in publicMethodModifiers.Where(x => x.Name.StartsWith("set")))
            {
                sb.AppendLine($"{method.Name} have to be private!");
            }

            return sb.ToString();
        }
    }
}