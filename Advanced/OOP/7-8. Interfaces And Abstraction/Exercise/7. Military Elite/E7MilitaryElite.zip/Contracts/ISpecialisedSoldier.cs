﻿
using E7MilitaryElite.Enumerations;

namespace E7MilitaryElite.Contracts
{
    public interface ISpecialisedSoldier : IPrivate
    {
        Corps Corps { get; }


    }
}
