﻿

namespace Telephony
{
    public interface IBrowseable
    {
        void Browse(string url);

    }
}
