﻿

namespace Telephony
{
    public interface Icallable
    {
        void Call(string number);

    }
}
