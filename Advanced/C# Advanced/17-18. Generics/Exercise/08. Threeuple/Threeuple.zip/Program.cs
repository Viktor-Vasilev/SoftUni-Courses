﻿using System;

namespace E8Threeuple
{
    public class Program
    {
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split();
            Threeuple<string, string, string> threeuple1 = new Threeuple<string, string, string>(input[0] + " " + input[1], input[2], input[3]);


            string[] input2 = Console.ReadLine().Split();
            bool isDrunk = input[2] == "drunk" ? true : false;
            Threeuple<string, int, bool> threeuple2 = new Threeuple<string, int, bool>(input2[0], int.Parse(input2[1]), isDrunk);


            string[] input3 = Console.ReadLine().Split();
            Threeuple<string, double, string> threeuple3 = new Threeuple<string, double, string>(input3[0], double.Parse(input3[1]), input3[2]);


            Console.WriteLine(threeuple1);
            Console.WriteLine(threeuple2);
            Console.WriteLine(threeuple3);

        }
    }
}
